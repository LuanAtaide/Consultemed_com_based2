
INSERT INTO TB_USUARIOS (login, senha) VALUES ('cbgomes','123');
INSERT INTO TB_USUARIOS (login, senha) VALUES ('maria','123');
INSERT INTO TB_USUARIOS (login, senha) VALUES ('barbara','123');
INSERT INTO TB_USUARIOS (login, senha) VALUES ('gabryella','123');
