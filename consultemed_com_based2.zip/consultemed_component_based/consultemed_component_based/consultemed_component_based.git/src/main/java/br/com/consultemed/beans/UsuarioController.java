/**
 * 
 */
package br.com.consultemed.beans;

import javax.faces.bean.ManagedBean;
import javax.inject.Inject;

/**
 * @author carlosbarbosagomesfilho
 *
 */
@ManagedBean
public class UsuarioController{

	
	
	
}
