/**
 * 
 */
package br.com.consultemed.utils;

/**
 * @author carlosbarbosagomesfilho
 * Classe que representa as constantes do sistema.
 */

public class Constantes {

	//PERSISTENCE_UNITE
	public static final String PERSISTENCE_UNIT_NAME = "consultemed";
	
	
	
}
